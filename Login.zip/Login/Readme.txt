Author: Yogesh singh
Author URL: https://makitweb.com/
Author Email: makitweb@gmail.com
Tutorial Link: https://makitweb.com/create-simple-login-page-with-php-and-mysql/

Instructions -
1. Import attached users.sql file in your database.
2. Update config.php file.

